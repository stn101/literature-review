<?php
print "
<html lang=\"en\">
<head>
	<meta charset=\"utf-8\">
	<title>Your Grade</title>
</head>";

print"<body bgcolor=\"pink\">";

print "<font size =\"5\">
We have received your grades, thank you!</font><br>";

$q1=$_POST['Quiz_1'];
$q2=$_POST['Quiz_2'];
$a1=$_POST['Assignment_1'];
$a2=$_POST['Assignment_2'];
$a3=$_POST['Assignment_3'];
$m=$_POST['Midtermexam'];
$f=$_POST['Finalexam'];
$p=$_POST['Project'];

$t=(($q1/10)*0.05+($q2/10)*0.05+($a1/100)*0.05+($a2/100)*0.05+
				   ($a3/100)*0.05+ ($m/50)*0.1+($f/100)*0.4+($p/25)*0.25)*100;
print "<font size=\"5\">";
print "Your grade for each coursework is below:<br>";
print "<ul>";
print "<li>Quiz 1 = $q1</li>";	
print "<li>Quiz 2 = $q2</li>";
print "<li>Assignment 1 = $a1</li>";
print "<li>Assignment 2 = $a2</li>";
print "<li>Assignment 3 = $a3</li>";	
print "<li>Midterm exam = $m</li>";
print "<li>Final exam = $f</li>";
print "<li>Project = $p</li>";
print "</ul>";
print "</font>";			   
print "<p style = \"color:red;font-size:20px;\">Your total grade for this course is: $t</p>";

print "
</body>
</html>
";
?>