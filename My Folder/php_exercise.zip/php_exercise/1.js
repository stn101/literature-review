
	   function gradeCollection() 
	   {
         if(( document.gradeForm.Quiz_1.value == "" )||
		 (document.gradeForm.Quiz_1.value>10)||
		 (document.gradeForm.Quiz_1.value<0))			 
         {
            alert( "the quiz 1 grade must be 0<=grade<=10" );
            document.gradeForm.Quiz_1.focus() ;
            return false;
         }
		 
         if(( document.gradeForm.Quiz_2.value == "" )||
		 (document.gradeForm.Quiz_2.value>10)||
		 (document.gradeForm.Quiz_2.value<0))			 
         {
            alert( "the quiz 2 grade must be 0<=grade<=10" );
            document.gradeForm.Quiz_2.focus() ;
            return false;
         }		 
		 
         if(( document.gradeForm.Assignment_1.value == "" )||
		 (document.gradeForm.Assignment_1.value>100)||
		 (document.gradeForm.Assignment_1.value<0))			 
         {
            alert( "the assignment 1 grade must be 0<=grade<=100" );
            document.gradeForm.Assignment_1.focus() ;
            return false;
         }			 
		 
         if(( document.gradeForm.Assignment_2.value == "" )||
		 (document.gradeForm.Assignment_2.value>100)||
		 (document.gradeForm.Assignment_2.value<0))			 
         {
            alert( "the assignment 2 grade must be 0<=grade<=100" );
            document.gradeForm.Assignment_2.focus() ;
            return false;
         }		 
		 
		 
         if(( document.gradeForm.Assignment_3.value == "" )||
		 (document.gradeForm.Assignment_3.value>100)||
		 (document.gradeForm.Assignment_3.value<0))			 
         {
            alert( "the assignment 3 grade must be 0<=grade<=100" );
            document.gradeForm.Assignment_3.focus() ;
            return false;
         }		 
		 
         if(( document.gradeForm.Midtermexam.value == "" )||
		 (document.gradeForm.Midtermexam.value>50)||
		 (document.gradeForm.Midtermexam.value<0))			 
         {
            alert( "the midterm grade must be 0<=grade<=50" );
            document.gradeForm.Midtermexam.focus() ;
            return false;
         }		 
	
         if(( document.gradeForm.Finalexam.value == "" )||
		 (document.gradeForm.Finalexam.value>100)||
		 (document.gradeForm.Finalexam.value<0))			 
         {
            alert( "the final grade must be 0<=grade<=100" );
            document.gradeForm.Finalexam.focus() ;
            return false;
         }	
		 
         if(( document.gradeForm.Project.value == "" )||
		 (document.gradeForm.Project.value>25)||
		 (document.gradeForm.Project.value<0))			 
         {
            alert( "the Project grade must be 0<=grade<=25" );
            document.gradeForm.Project.focus() ;
            return false;
         }	 	


         var q1= document.gradeForm.Quiz_1.value;
         var q2= document.gradeForm.Quiz_2.value;
         var a1= document.gradeForm.Assignment_1.value;
         var a2= document.gradeForm.Assignment_2.value;
         var a3= document.gradeForm.Assignment_3.value;	
		 var m=document.gradeForm.Midtermexam.value;
		 var f=document.gradeForm.Finalexam.value;
		 var p=document.gradeForm.Project.value;
		 var total = ((q1/10)*0.05+(q2/10)*0.05+(a1/100)*0.05+(a2/100)*0.05+
				   (a3/100)*0.05+ (m/50)*0.1+(f/100)*0.4+(p/25)*0.25)*100;
			 alert( total );
		 return true;  
       }

